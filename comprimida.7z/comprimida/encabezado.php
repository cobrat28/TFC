<!--Este es el encabezado y se mostrara en la parte superior de ciertas páginas clave como puede ser la principal.-->
<nav class="top">
        <div class="uno"><a href=pagina_principal.php><img class="uno_img" src="Imagenes\Logo_solo.png" height="50%"></a></div>
        <div class="dos">
            <p><a href="encuestas.php">Encuestas</a></p>
        </div>
        <div class="tres">
            <p><a href="empresa.php">Empresas</a></p>
        </div>
        <div class="cuatro">
            <p><a href="perfil.php">Mi Perfil</a></p>
        </div>
    </nav>
